
# PEF Shoes Demo

This React web app helps suppliers input data for Product Environmental Footprint (PEF) calculations on shoes.

## Features

- Add multiple shoe components (30–50+)
- Record material composition, processes, energy use, and loss rate
- Export collected data as JSON or CSV

## Setup

1. Clone the repo
2. Run `npm install`
3. Run `npm start` for local testing
4. Deploy using `npm run deploy` (with GitHub Pages setup)

## Live Demo

Once deployed, the live site will be available at:
`https://YOUR_USERNAME.github.io/pef-shoes-demo`
